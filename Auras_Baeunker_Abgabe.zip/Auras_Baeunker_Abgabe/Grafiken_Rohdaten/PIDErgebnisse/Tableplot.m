function [] = Tableplot(data) 
plotyy(data{:,1},data{:,2},data{:,1},data{:,4})
end