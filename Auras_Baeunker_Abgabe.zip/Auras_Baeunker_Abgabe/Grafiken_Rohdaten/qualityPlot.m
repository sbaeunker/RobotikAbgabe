yLa= "Geschwindigkeit in cm/s"
xLa= "Zeit in sekunden"
name= ""

figure('Name',name,'Position',[200 200 900 600], 'PaperPositionMode','auto')
avMeanNo = 10;
%for i = 1:(length(SensorDataWackeln{:,3})-avMeanNo)
%    av1(i)= sum(accGlobal(i:i+avMeanNo,3))/(avMeanNo+1);
%    av2(i)= sum(SensorDataWackeln{i:i+avMeanNo,5})/(avMeanNo+1); 
%    av3(i)= sum(accGlobal(i:i+avMeanNo,3))/(avMeanNo+1); 
%end
%plot(SensorDataWackeln{1:length(av1),1},av1)
%hold
%plot(SensorDataWackeln{1:length(av1),1},av2)

plot(SensorDataFuzzy3{:,1}-min(SensorDataFuzzy3{:,1}),SensorDataFuzzy3{:,2},'k--')
hold
plot(SensorDataFuzzy3{:,1}-min(SensorDataFuzzy3{:,1}),SensorDataFuzzy3{:,4})
%plot(SensorDataPbesser{:,1}-min(SensorDataPbesser{:,1}),SensorDataPbesser{:,4})
%plot(SensorDataPIfinal{:,1}-min(SensorDataPIfinal{:,1}),SensorDataPIfinal{:,4})
%plot(SensorDataPIDfinalviertel{:,1}-min(SensorDataPIDfinalviertel{:,1}),SensorDataPIDfinalviertel{:,4})
%plot(SensorDataPIDschlecht{:,1}-min(SensorDataPIDschlecht{:,1}),SensorDataPIDschlecht{:,4})
%plotyy(LocatorDataTragen{:,1},LocatorDataTragen{:,6},SensorDataTragen{:,1},SensorDataTragen{:,2})
ylabel(yLa,...
'FontUnits','points',...
'FontWeight','normal',...
'FontSize',16)
xlabel(xLa,...
'FontUnits','points',...
'FontWeight','normal',...
'FontSize',16)

title(name,...
'FontUnits','points',...
'FontWeight','bold',...
'FontSize',20)
legend('F�hrg��e', 'Fuzzy+PI+Vorsteuerung', 'PI', 'PID')
set(gca, 'FontWeight', 'normal', 'FontSize', 15, 'XTickLabelRotation', 0)
