
figure('Name',name,'Position',[200 200 900 600], 'PaperPositionMode','auto')
%avMeanNo = 10;
%for i = 1:(length(SensorDataWackeln{:,3})-avMeanNo)
%    av1(i)= sum(accGlobal{i:i+avMeanNo,1})/(avMeanNo+1);
%    av2(i)= sum(accGlobal{i:i+avMeanNo,2})/(avMeanNo+1); 
%    av3(i)= sum(accGlobal{i:i+avMeanNo,3})/(avMeanNo+1); 
%end


[AX,H1,H2]  = plotyy(SensorDataDirac{:,1},SensorDataDirac{:,2},SensorDataDirac{:,1},abs(SensorDataDirac{:,32}))
yLa1= "Drive Funktion Y "
yLa2= "Geschwindigkeit Y in cm/s"
xLa= "Zeit in Sekunden"
name= "Rampe Geschwindigkeit Y"
set(get(AX(1),'Ylabel'),'String',yLa1) 
set(get(AX(1),'Ylabel'),'FontSize',16)
set(get(AX(2),'Ylabel'),'String',yLa2) 
set(get(AX(2),'Ylabel'),'FontSize',16)
set(H1,'LineWidth',1,'Color',[0 0 1]) 
set(H2,'LineWidth',1,'Color',[1 0 0])

xlabel(xLa,...
'FontUnits','points',...
'FontWeight','normal',...
'FontSize',16)

title(name,...
'FontUnits','points',...
'FontWeight','bold',...
'FontSize',20)

set(gca, 'FontWeight', 'normal', 'FontSize', 15)
