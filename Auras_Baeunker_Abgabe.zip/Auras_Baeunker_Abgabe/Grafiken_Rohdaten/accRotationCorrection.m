t = SensorDataWackeln{:,1};
accX = SensorDataWackeln{:,3};
accY = SensorDataWackeln{:,4};
accZ = SensorDataWackeln{:,5};
acc = [accX accY accZ];
%Ryaw = zeros(length(accX),3,3);
%Rpitch = zeros(length(accX),3,3);
%Rroll = zeros(length(accX),3,3);
%R = zeros(length(accX),3,3);
accGlobal = zeros(length(accX),3);
pitch = SensorDataWackeln{:,13} * pi/180;
roll = SensorDataWackeln{:,14} * pi/180;
yaw = SensorDataWackeln{:,15}* pi/180;
alpha=yaw;
beta=-1*roll;
gamma=-1*pitch;
for i= 1:length(yaw)
Rz = [ cos(alpha(i)) -sin(alpha(i)) 0 ; sin(alpha(i)) cos(alpha(i)) 0 ; 0 0 1 ];
Ry = [ cos(beta(i)) 0 sin(beta(i)); 0 1 0 ;  -sin(beta(i)) 0  cos(beta(i)) ];
Rx = [ 1 0 0 ;0 cos(gamma(i)) -sin(gamma(i))  ;0 sin(gamma(i)) cos(gamma(i))  ];
R = Rx * Ry * Rz;
accGlobal(i,:) =  R*acc(i,:)';
end
plot(accGlobal(:,3))
hold
plot(acc(:,3))