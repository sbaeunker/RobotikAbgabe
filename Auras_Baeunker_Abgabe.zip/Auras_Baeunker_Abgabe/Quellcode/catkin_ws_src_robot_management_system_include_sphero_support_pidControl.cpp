#define PI 3.14159265
#define DZ 0.03
#include "pidControl.hpp"





pidControl::pidControl(){
	;
}

pidControl::pidControl(ros::Publisher& controller_pub){
	
	
	std::cout<<"Sphero moved to controller" << std::endl;
	//write sensor data to csv used for testing
	//sensorFile.open("SensorData.csv");	
	//sensorFile << "time, fuehr, stell, messV, messA, fuzzy "<< std::endl;
	this->controller_pub = controller_pub;
	begin = ros::Time::now();
	
}

void pidControl::controlStop(){
	controlDrivePID= false;
	w = 0.0f;
	driveY=0.0f;
	driveX=0.0f;
	
}

void pidControl::normalize(float& x, float& y){
	//normalizing for direction vector
	float abs = sqrt(x*x+y*y);
	x=x/abs;
	y=y/abs;
}

void pidControl::controlChangeDirection(float x, float y){
	//setting direction
	normalize(x,y);
	//integral = integral * 
	xDirection = x;
	yDirection = y;
}


void pidControl::controlStart(float fuehr){
	//initialize values for PID control
	std::cout<<"started Control" << std::endl;
	ealt = 0.0f;
	w=fuehr;
	controlDrivePID= true;
	integral = 0.0f;
	differential = 0.0f;
	talt = ros::Time::now();
	
	
}

void pidControl::controllerCallback(SpheroClient& sp){
	
	
	if(controlDrivePID){
		robot_management_system::SpheroSensorData sensorData = sp.getSensorData();
		
		//Vektorprojektion von Sensordaten auf Fahrtrichtung (als Einheitsvetor)
		float vAbs = xDirection * sensorData.velX + yDirection * sensorData.velY;
		//control with total velocity
		controlDrive(vAbs); 
	}
}

void pidControl::controlDrive(float vAbs){
	
	ta = (ros::Time::now()-talt).toSec();	
	talt = ros::Time::now();//
	//standard PID formula
	float e = w-vAbs;
	integral += e;
	float differential = (e - ealt);
	ealt = e;
	float y = pv*w + kp *  e + ki*ta * integral + kd* differential / ta;
	
	//Sphero will turn 180 degrees if y<0 messing up continous driving.
	if(y<0.0){
		y=0.0f;
	}
	
	//std::cout<<"Stellgröße: "<<std::to_string(y)<<std::endl;
	
	//setting final controller output values
	driveX=y*yDirection;
	driveY=y*xDirection;
	
	
	//publishing controller data
	std_msgs::Float32MultiArray array;
		
	array.data.clear();
	array.data.push_back(w);
	array.data.push_back(y);
	array.data.push_back(vAbs);
	
	controller_pub.publish(array);
	
	/*
	sensorFile << (ros::Time::now()-begin).toSec();
	sensorFile << "," << std::to_string(w);
	sensorFile << "," << std::to_string(y);
	sensorFile << "," << std::to_string(vAbs);
	sensorFile << std::endl;
	* */
	
}

//TODO deconstructor with sensorFile close


