#include <ros/ros.h>
#include <sphero_support/SpheroClient.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <robot_management_system/SpheroRequest.h>
#include <robot_management_system/SpheroSensorData.h>
#include <robot_management_system/SpheroConfig.h>
#include <std_msgs/Float32MultiArray.h>


struct FuzzyMember {
	float lower;//Membership Function Grenzen
	float upper;
	float width;
	FuzzyMember();
	FuzzyMember(float lower, float upper, float width);	
	float getDom(float x);	
	void getCorners(float y,float &cornerL,float &cornerU);
};

struct FuzzyRule {
	FuzzyMember a;
	FuzzyMember b;
	FuzzyMember out;
	FuzzyRule(FuzzyMember &a,FuzzyMember &b,FuzzyMember &out);
	float getOutputDegree(float x,float y);
	float getOutputArea(float x, float y);	
	
};

class fuzzyControl
{
	public:
		fuzzyControl();
		fuzzyControl(ros::Publisher& controller_pub);
		void controlChangeDirection(float x, float y);
		void controlStop();
		void controlStart(float fuehr);
		void controllerCallback(SpheroClient& sp);
		float driveX=0.0f;
		float driveY=0.0f;
	private:		
		SpheroClient meinSphero1;
		ros::Publisher controller_pub;
		std::ofstream sensorFile;
		std::ofstream actionFile;
		ros::Time begin;
		float driveVelocity=0.0f;
		float callBackFrequency= 100.0f;
		float controlFrequency= 30.0f;
		float xDirection = 0.0f;
		float yDirection = 1.0f;
		bool controlDriveFuzzy= false;
		
		float minE = -500.0f;
		float maxE = 500.0f;
		//TODO acc werte
		float minA = -500.0f;
		float maxA = 500.0f;
		float minOut = -0.15f;
		float maxOut = 0.15f;

		int noMembersE = 7;
		int noMembersA = 7;
		int noMembersOut = 7;

		FuzzyMember * eMembers;
		FuzzyMember * aMembers;
		FuzzyMember * outMembers;
		FuzzyRule ** ruleSet;

		float centerOfSumsZaehler = 0.0f;
		float centerOfSumsNenner = 0.0f;

		float Pv = 1.0/2000.0f;
		float w = 0.0f;

		ros::Time talt;
		float ta;
		float integralFuzzy = 0.0;
		float kiFuzzy = 0.8f;
		float kpFuzzy = 0.8f;
		
		void transformAcceleration(float& accX, float& accY, float& accZ, float alpha, float beta, float gamma);		
		void fuzzyDrive(float vAbs, float aAbs);
		void normalize(float& x, float& y);
	
};
