#include <ros/ros.h>
#include <sphero_support/SpheroClient.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <robot_management_system/SpheroRequest.h>
#include <robot_management_system/SpheroSensorData.h>
#include <robot_management_system/SpheroConfig.h>
#include <std_msgs/Float32MultiArray.h>



class pidControl
{
	public:
		pidControl();
		pidControl(ros::Publisher& controller_pub);
		void controlChangeDirection(float x, float y);
		void controlStop();
		void controlStart(float fuehr);
		void controllerCallback(SpheroClient& sp);
		float driveY=0.0f;
		float driveX=0.0f;
		
	private:
		ros::Publisher controller_pub;
		std::ofstream sensorFile;
		std::ofstream actionFile;
		ros::Time begin;
		float callBackFrequency= 100.0f;
		float controlFrequency= 30.0f;
		float xDirection = 0.0f;
		float yDirection = 1.0f;
		
		bool controlDrivePID= false;
		float u;
		float y;
		float w;
		float kp=0.000145f;
		float ki=0.00021f;
		float kd=0.0f;
		float pv = 1.0/3000.0;
		float ta = 1.0/callBackFrequency;
		float differential = 0.0;
		float integral = 0.0;
		float ealt = 0.0;
		ros::Time talt;
		
				
		void controlDrive(float vAbs);
		void normalize(float& x, float& y);
		void setSpheroConfig();
	
};
