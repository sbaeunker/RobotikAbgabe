#define PI 3.14159265
#define DZ 0.03
#include "fuzzyControl.hpp"


//structs für fuzzymengen
FuzzyMember::FuzzyMember(){//default constructor zur array initialisierung
		this->lower=0.0;
		this->upper=0.0;
	}
FuzzyMember::FuzzyMember(float lower, float upper, float width){
		this->lower = lower;
		this->upper = upper;
		this->width = width;
	}
	
float FuzzyMember::getDom(float x){//get degree of membership(Grad der Zugehörigkeit)
		//liefert y wert von Fuzzymengen, welche als Hutfunktionen dargestellt werden
		
		if(x<(lower+width/2.0) && x > lower){
			return (2.0f/width)*(x-lower);
		}else if(x>=(lower+width/2.0) && x < upper){
			return (2.0f/width)*(-x+upper);
		}else return 0.0f;
	}

void FuzzyMember::getCorners(float y,float &cornerL,float &cornerU){
		//liefert die Grenzen des trägers der Hutfunktion
		cornerL = lower+(y/(2.0f/width));
		cornerU = upper+(-y/(2.0f/width));	
	}	




FuzzyRule::FuzzyRule(FuzzyMember &a,FuzzyMember &b,FuzzyMember &out){
		this->a = a;
		this->b = b;
		this->out = out;
	}
float FuzzyRule::getOutputDegree(float x,float y){//liefert den Grad der Zugehörigkeit für die Ausgangsmenge
		float aDGZ = a.getDom(x);
		float bDGZ = b.getDom(y);
		//std::cout<< "A Dom: " << std::to_string(aDGZ)<<" B Dom: " << std::to_string(bDGZ)<<std::endl;
		return !(bDGZ<aDGZ)?aDGZ:bDGZ;
	}
float FuzzyRule::getOutputArea(float x, float y){//berechnet die Fläche der zugehörigen Ausgangsmenge
		float height = getOutputDegree(x,y);
		
		float cornerL,cornerU;
		
		out.getCorners(height,cornerL,cornerU);
		/*
		std::cout<< "A Upper: " << std::to_string(a.upper)<<" A Lower: " << std::to_string(a.lower)<<std::endl;
		std::cout<< "B Upper: " << std::to_string(b.upper)<<" B Lower: " << std::to_string(b.lower)<<std::endl;
		std::cout<< "Out Upper: " << std::to_string(out.upper)<<" Out Lower: " << std::to_string(out.lower)<<std::endl;
		std::cout<< "Height: " << std::to_string(height)<<" CornerL: " << std::to_string(cornerL)<<" CornerU: " << std::to_string(cornerU)<<std::endl;
		*/
		//Nur gleichmaessige Trapeze als membership functions in dieser Implementierung
		float A = height * ( out.upper-out.lower+cornerU-cornerL)/2.0;
		if(A<0.0f) std::cout<< "ERROR A negativ: " <<std::endl;
		return A;
	}	


fuzzyControl::fuzzyControl(){
	;
}


fuzzyControl::fuzzyControl(ros::Publisher& controller_pub){
	
	
	
	sensorFile.open("SensorData.csv");	
	sensorFile << "time, fuehr, stell, messV, messA, fuzzy "<< std::endl;
	
	begin = ros::Time::now();
	

	
	this->controller_pub = controller_pub;
	//speich allokieren für Fuzzymengen structs
	eMembers = (FuzzyMember*)malloc(sizeof(FuzzyMember)*noMembersE);//  FuzzyMember[noMembersE];
	aMembers = (FuzzyMember*)malloc(sizeof(FuzzyMember)*noMembersA);
	outMembers = (FuzzyMember*)malloc(sizeof(FuzzyMember)*noMembersOut);
	ruleSet = new  FuzzyRule *[noMembersE];
	
	
	//Regeldifferenz Member E
	float width= 2*(maxE-minE)/(noMembersE -1);
	for(int i=0; i<noMembersE; i++){//initialisieren der klassen und deklarieren des Rulesets
		ruleSet[i] = (FuzzyRule*)malloc(sizeof(FuzzyRule)*noMembersA);
		eMembers[i]= FuzzyMember(minE+i*width/2-width/2,minE+i*width/2+width/2,width);
		std::cout<<"FuzzyMenge E"<<std::to_string(i+1)<<" von:"<<std::to_string(eMembers[i].lower)<<"bis "<<std::to_string(eMembers[i].upper)<< std::endl;
	}
	//Fuzzymenge a
	width= 2*(maxA-minA)/(noMembersA -1);
	for(int i=0; i<noMembersA; i++){//initialisieren der klassen und deklarieren des Rulesets
		aMembers[i]= FuzzyMember(minA+i*width/2-width/2,minA+i*width/2+width/2,width);
		std::cout<<"FuzzyMenge A"<<std::to_string(i+1)<<" von:"<<std::to_string(aMembers[i].lower)<<"bis "<<std::to_string(aMembers[i].upper)<< std::endl;
	}
	//Ausgangsmenge
	width= 2*(maxOut-minOut)/(noMembersOut -1);
	for(int i=0; i<noMembersOut; i++){//initialisieren der klassen und deklarieren des Rulesets
		outMembers[i]= FuzzyMember(minOut+i*width/2-width/2,minOut+i*width/2+width/2,width);
		std::cout<<"FuzzyMenge Out"<<std::to_string(i+1)<<" von:"<<std::to_string(outMembers[i].lower)<<"bis "<<std::to_string(outMembers[i].upper)<< std::endl;
	}
	
	//initialisieren des Rulesets siehe ausarbeitung fuer uebersichtliche Tabelle
	for(int i=0; i<noMembersE; i++){
		for(int j=0; j<noMembersA; j++){
			if(i+j==7){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[3]);
			}else if(i+j==8){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[2]);
			}else if(i+j==9){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[1]);
			}else if(i+j>9){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[0]);
			}else if(i+j==6){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[4]);
			}else if(i+j==5){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[5]);
			}else if(i+j<5){
				ruleSet[i][j] = FuzzyRule(eMembers[i],aMembers[j],outMembers[6]);
			}		
		}
	}
}
	


void fuzzyControl::transformAcceleration(float& accX, float& accY, float& accZ, float alpha, float beta, float gamma){
	//transformieren der beschleunigung in ein Weltkoordinatensystem
	alpha=alpha*PI/180;
	beta=-beta*PI/180;
	gamma=-gamma*PI/180;
	float aX=cos(alpha)*cos(beta)*accX+(cos(alpha)*sin(beta)*sin(gamma)-sin(alpha)*cos(gamma))*accY+(cos(alpha)*sin(beta)*cos(gamma)+sin(alpha)*sin(gamma))*accZ;
	float aY=sin(alpha)*cos(beta)*accX+(sin(alpha)*sin(beta)*sin(gamma)-cos(alpha)*cos(gamma))*accY+(sin(alpha)*sin(beta)*cos(gamma)+cos(alpha)*sin(gamma))*accZ;
	float aZ=-1.0*sin(beta)*accX+cos(beta)*sin(gamma)*accY+cos(beta)*cos(gamma)*accZ;
	accX = aX;
	accY = aY;
	accZ = aZ;
}

void fuzzyControl::controlStop(){
	controlDriveFuzzy = false;
	w = 0.0f;
	driveX=0.0f;
	driveY=0.0f;	
}

void fuzzyControl::normalize(float& x, float& y){
	//normalisieren des richtungsvektors
	float abs = sqrt(x*x+y*y);
	x=x/abs;
	y=y/abs;
}

void fuzzyControl::controlChangeDirection(float x, float y){
	//Richtung ändern
	normalize(x,y);
	//integral = integral * 
	xDirection = x;
	yDirection = y;
}


void fuzzyControl::controlStart(float fuehr){
	controlDriveFuzzy = true;
	w = fuehr;
	integralFuzzy = 0.0f;
	talt = ros::Time::now();
}

void fuzzyControl::controllerCallback(SpheroClient& sp){
	
	//sensorData.velX
	if(controlDriveFuzzy){
		robot_management_system::SpheroSensorData sensorData = sp.getSensorData();
		float accX =sensorData.accXraw;
		float accY =sensorData.accYraw;
		float accZ =sensorData.accZraw;
		
		float pitch =sensorData.anglePitch;
		float roll =sensorData.angleRoll;
		float yaw = sensorData.angleYaw;
		transformAcceleration(accX,accY,accZ,pitch,roll,yaw);
		//Vektorprojektion von Sensordaten auf Fahrtrichtung (als Einheitsvetor)
		float vAbs = xDirection * sensorData.velX + yDirection * sensorData.velY;
		float aAbs = xDirection * accX + yDirection * accY;
		fuzzyDrive(vAbs,aAbs); 
	}
}

void fuzzyControl::fuzzyDrive(float vAbs, float aAbs){
	centerOfSumsZaehler = 0.0f;
	centerOfSumsNenner = 0.0f;
	float e=vAbs-w;
	//außerhalb des definitionsbereichs aller Fuzzymengen
	if(e<minE){//auf maximale stellgroeßen aenderung setzen
		e=minE;
	}else if(e>maxE){//auf minimale stellgroeße setzen
		e=maxE;
	}
	//außerhalb des definitionsbereichs aller Fuzzymengen
	if(aAbs < minA){
		aAbs = minA;
	}else if(aAbs > maxA){
		aAbs = maxA;
	}
	
	//Summenschwerpunktmehtode: alle Flächen zusammenzählen
	for(int i=0; i<noMembersE; i++){
		for(int j=0; j<noMembersA; j++){
			float area =ruleSet[i][j].getOutputArea(e,aAbs);
			centerOfSumsZaehler+=area*(ruleSet[i][j].out.upper+ruleSet[i][j].out.lower)/2.0;
			centerOfSumsNenner+= area;
			//std::cout<< "Area of Rule " << std::to_string(i)<< std::to_string(j)<<" :"<< std::to_string(area)<<std::endl<<std::endl;
		}
	}
	float fuzzyOut = centerOfSumsZaehler/centerOfSumsNenner;
	
	
	ta = (ros::Time::now()-talt).toSec();
	talt = ros::Time::now();
	
	
	integralFuzzy += fuzzyOut;
	float y= Pv * w + kpFuzzy*fuzzyOut + kiFuzzy*ta * integralFuzzy; //fuzzyPID:
	//Stellgröße darf nicht kleiner 0 sein da der Sphero sich sonst dreht.
	if(y<0.0f){
		y=0.0f;
	}
	//finale stellgrößen
	driveX=y*yDirection;
	driveY=y*xDirection;
	
	//publish sensordata
	std_msgs::Float32MultiArray array;
	//Clear array
	array.data.clear();
	array.data.push_back(w);
	array.data.push_back(y);
	array.data.push_back(vAbs);
	array.data.push_back(aAbs);
	controller_pub.publish(array);	
	
}

