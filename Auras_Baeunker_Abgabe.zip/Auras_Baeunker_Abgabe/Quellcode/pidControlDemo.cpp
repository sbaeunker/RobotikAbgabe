#include <ros/ros.h>
#include <sphero_support/SpheroClient.hpp>
#include <iostream>
#include <fstream>
#include <math.h>
#include <robot_management_system/SpheroRequest.h>
#include <robot_management_system/SpheroLocatorData.h>
#include <robot_management_system/SpheroConfig.h>

#include <sphero_support/fuzzyControl.hpp>
#include <sphero_support/pidControl.hpp>






SpheroClient meinSphero1;
//fuzzyControl controller;

pidControl controller;
ros::Publisher controller_pub;

bool pid_on=true;


void locatorDataCB(SpheroClient& sp)
{
	;
}



void sensorDataCB(SpheroClient& sp)
{
	controller.controllerCallback(sp);
if(pid_on)
{
	meinSphero1.drive(controller.driveX,controller.driveY);
//std::cout<<"controlled"<<std::endl;
}
else
{
//	meinSphero1.drive(0.3,0.3);
//std::cout<<"uncontrolled"<<std::endl;
}
	
//	std::cout<<"Stell-X: "<<std::to_string(controller.driveX)<<std::endl;
//	std::cout<<"Stell-Y: "<<std::to_string(controller.driveY)<<std::endl;
}

int main(int argc, char** argv)
{	
	
	ros::init(argc, argv, "testSpheroClient");
	ros::NodeHandle n;
	ros::AsyncSpinner spinner(2); // erstellt einen Multithread Spinner
	spinner.start(); //Starte Spinner in 2 Threads
	
	
	
	meinSphero1 = SpheroClient(true, &sensorDataCB, &locatorDataCB);

	
	meinSphero1.requestAndWait();
	meinSphero1.setColor(0.0,0.0,1.0,0.3);
	
	ros::Duration(2.0).sleep();
	
	robot_management_system::SpheroConfig spheroConfig;
	meinSphero1.getConfig(spheroConfig);
	spheroConfig.stabilisationActive = true;
	spheroConfig.sensorStreamingFreq = int(30);
	spheroConfig.sensorMask.angle = true;
	spheroConfig.sensorMask.velocity = true;
	spheroConfig.sensorMask.accRaw = true;
	
		
	meinSphero1.setConfig(spheroConfig);
	
	std::cout<<"Sphero konfiguriert"<< std::endl;	
	controller_pub = n.advertise<std_msgs::Float32MultiArray>("controllerDataArray", 30);

	controller = pidControl(controller_pub);
	//controller = fuzzyControl(controller_pub);
	ros::Duration(3.0).sleep();
	while(true){
	
//GRÜN = 3s Fahren pro Richtung mit PID (1s Pause dazwischen)
	meinSphero1.setColor(0.0,1.0,0.0,1.0);
	controller.controlChangeDirection(1.0f,1.0f);
	controller.controlStart(500.0f);
	ros::Duration(3.0).sleep();
	controller.controlStop();
	ros::Duration(1.0).sleep();
	controller.controlChangeDirection(-1.0f,-1.0f);
	controller.controlStart(500.0f);
	ros::Duration(3.0).sleep();
	controller.controlStop();

//ROT = 3s Stop
	meinSphero1.setColor(1.0,0.0,0.0,1.0);
	ros::Duration(3.0).sleep();

//BLAU=3s Fahren pro Richtung original drive-Befehl (1s Pause dazwischen)
	meinSphero1.setColor(0.0,0.0,1.0,1.0);	
	pid_on=false;	//PID überbrücken
	controller.controlChangeDirection(1.0f,1.0f);
	controller.controlStart(1.0f);	//CB trotzdem für Datenausgabe starten
	meinSphero1.drive(0.2,0.2);
	ros::Duration(3.0).sleep();
	meinSphero1.stop(0);
	controller.controlStop();
	ros::Duration(1.0).sleep();
	controller.controlChangeDirection(-1.0f,-1.0f);
       controller.controlStart(1.0f);
	meinSphero1.drive(-0.2,-0.2);
	ros::Duration(3.0).sleep();
	meinSphero1.stop(0);
	controller.controlStop();
	pid_on=true;
	
//WEISS = 10s Stop
	meinSphero1.setColor(1.0,1.0,1.0,1.0);
	ros::Duration(10.0).sleep();
	

	}
	spinner.stop();	
	ros::shutdown();
	return 0;
}

/*
Data - Array:
0 -> Sollwert aus controlStart
1 -> berechneter Wert PID ansteuerung Drive-Befehl  -->  Bei 500f auf glatter Fläche etwa 0.2
2 -> Istwert zu controlStart ? -> Geschwindigkeit
*/
