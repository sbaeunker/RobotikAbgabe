Im Latex Project zus�tzlich verwendete Pakete:

\usepackage{multirow}
\usepackage{slashbox}
\usepackage{graphicx}
\usepackage{wrapfig}

Der Gesamte Quellcode inklusive cmakelist kann unter https://gitlab.cvh-server.de/sbaeunker eingesehen werden.